package com.server.utils.types;

public class CohereGenerationResult {
  private String text;

  public String getText() {
    return this.text;
  }
}
