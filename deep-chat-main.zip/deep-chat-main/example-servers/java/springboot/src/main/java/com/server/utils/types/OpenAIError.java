package com.server.utils.types;

public class OpenAIError {
  private String message;

  public String getMessage() {
    return this.message;
  }
}
