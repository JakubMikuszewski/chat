package com.server.utils.types;

public class CohereChatResult {
  private String text;
  private String message;

  public String getText() {
    return this.text;
  }

  public String getMessage() {
    return this.message;
  }
}
