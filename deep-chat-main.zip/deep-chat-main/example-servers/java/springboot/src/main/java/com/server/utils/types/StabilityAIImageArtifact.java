package com.server.utils.types;

public class StabilityAIImageArtifact {
  private String base64;

  public String getBase64() {
    return this.base64;
  }
}
