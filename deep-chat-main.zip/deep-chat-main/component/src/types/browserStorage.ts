export type BrowserStorage = true | {key?: string; maxMessages?: number; clear?: () => void};
