import {ButtonStyles} from './button';

export interface GenericInputButtonStyles {
  // the reason why this is called styles is because the Button object encapsulates the style within this property
  styles?: ButtonStyles;
}
