export type FILE_TYPE = 'images' | 'gifs' | 'audio' | 'mixedFiles';
