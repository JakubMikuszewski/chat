export type DisplayLoadingBubble = boolean | {toggle: () => void};
