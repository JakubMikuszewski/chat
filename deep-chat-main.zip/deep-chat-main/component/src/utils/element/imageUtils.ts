export const BASE_64_PREFIX = 'data:image/png;base64,';
