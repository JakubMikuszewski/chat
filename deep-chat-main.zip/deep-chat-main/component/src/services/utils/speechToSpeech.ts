export class SpeechToSpeech {
  public static readonly SESSION_STARTED = 'sts-session-started';
  public static readonly SESSION_STOPPED = 'sts-session-stopped';
}
